// amd
requirejs.config({
    baseUrl: 'components'
});

require(['main.js'], function (main) {
});





// cmd
// seajs.config({
//   base: "/components"
// })

// // 加载入口模块
// seajs.use("/main")


