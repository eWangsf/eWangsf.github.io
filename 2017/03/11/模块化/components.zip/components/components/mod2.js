define(function () {
    console.log("require mod2.js ...");
    return {
        print: function () {
            console.log("print mod2");
        }
    }
})