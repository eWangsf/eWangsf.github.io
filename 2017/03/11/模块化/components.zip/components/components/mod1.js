define(function () {
    console.log("require mod1.js ...");
    return {
        print: function () {
            console.log("print mod1");
        }
    }
})