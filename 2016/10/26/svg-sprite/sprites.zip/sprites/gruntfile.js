

module.exports = function(grunt) {
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        svg_sprite: {
            options: {

            },
            base: {
                src: ['*.svg'],
                dest: './sprites',
                options: {
                    mode: {
                        symbol: true,
                        view: true,
                        css: true
                    }
                }
            }
        }
    });
   
    // Load NPM tasks
    grunt.loadNpmTasks('grunt-svg-sprite');

    grunt.registerTask('default', ['svg_sprite']);
};
